-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1
-- Время создания: Апр 22 2026 г., 17:42
-- Версия сервера: 10.4.32-MariaDB
-- Версия PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `ml`
--

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `first_name` varchar(100) DEFAULT NULL,
  `last_name` varchar(100) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `is_verified` tinyint(4) DEFAULT NULL,
  `verification_code` varchar(255) DEFAULT NULL,
  `reset_token` varchar(255) DEFAULT NULL,
  `reset_expires` datetime DEFAULT NULL,
  `avatar` varchar(255) DEFAULT NULL,
  `last_login` datetime DEFAULT current_timestamp(),
  `created_at` datetime DEFAULT current_timestamp(),
  `overall_points` int(11) DEFAULT 0,
  `last_activity` datetime DEFAULT current_timestamp(),
  `completed_lessons` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `password`, `is_verified`, `verification_code`, `reset_token`, `reset_expires`, `avatar`, `last_login`, `created_at`, `overall_points`, `last_activity`, `completed_lessons`) VALUES
(13, 'Bakdaulet', 'Assilkhan', 'bakdaulet.asilkhan26@fizmat.kz', '$2y$10$W60IQLiFy3lXSKOqWMPyb.5sVr5YBPP3ukeTxmt29G/uYx.Lr8i0K', 1, NULL, NULL, NULL, NULL, '2026-01-31 20:20:15', '2025-11-24 09:33:44', 45, '2025-12-07 21:40:31', 1),
(14, 'Zangar', 'Sunnatov', 'zangar.sunnatov26@fizmat.kz', '$2y$10$e3hYJlkoU8lhHSz69INKm.Z.z6/OhQ.7TazmI59co4ziz3j9hsh6K', 1, NULL, NULL, NULL, NULL, '2025-11-24 23:55:06', '2025-11-24 22:37:10', 65, '2025-11-24 22:54:36', 1),
(15, 'Bayanbek', 'Amantay', 'bayanbek.amantay@fizmat.kz', '$2y$10$zrRaUNSW8ZB5enFL8q2ec.uF8TXJp11T5LBu1QYwJ92UIN4gnsRba', 1, NULL, NULL, NULL, NULL, '2025-11-25 14:05:39', '2025-11-25 10:46:17', 0, '2025-11-25 10:46:17', 0);

-- --------------------------------------------------------

--
-- Структура таблицы `user_progress`
--

CREATE TABLE `user_progress` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `lesson_key` varchar(100) NOT NULL,
  `points` int(11) DEFAULT 0,
  `completed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `course_id` varchar(50) DEFAULT 'general'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Дамп данных таблицы `user_progress`
--

INSERT INTO `user_progress` (`id`, `user_id`, `lesson_key`, `points`, `completed_at`, `course_id`) VALUES
(18, 7, 'python-topic-1', 60, '2025-11-24 17:35:51', 'general'),
(19, 14, 'python-topic-1', 65, '2025-11-24 17:54:36', 'general'),
(25, 13, 'vision-topic-1', 45, '2025-12-07 16:40:31', 'general');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Индексы таблицы `user_progress`
--
ALTER TABLE `user_progress`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_user_lesson` (`user_id`,`lesson_key`),
  ADD KEY `idx_course` (`course_id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT для таблицы `user_progress`
--
ALTER TABLE `user_progress`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
