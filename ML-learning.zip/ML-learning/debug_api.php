<?php
session_start();
include 'db.php';

echo "<h2>🔍 Детальная проверка API</h2>";

// Проверяем сессию
echo "<h3>1. Сессия:</h3>";
echo "<pre>";
var_dump($_SESSION);
echo "</pre>";

// Проверяем подключение к БД
echo "<h3>2. Подключение к БД:</h3>";
if ($conn->connect_error) {
    echo "❌ Ошибка подключения: " . $conn->connect_error;
} else {
    echo "✅ Подключение успешно";
}

// Проверяем прогресс
echo "<h3>3. Прогресс пользователя (ID: " . ($_SESSION['user_id'] ?? 'нет') . "):</h3>";
if (isset($_SESSION['user_id'])) {
    $stmt = $conn->prepare("SELECT * FROM user_progress WHERE user_id = ?");
    $stmt->bind_param("i", $_SESSION['user_id']);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $progress = $result->fetch_all(MYSQLI_ASSOC);
    echo "<pre>";
    var_dump($progress);
    echo "</pre>";
}

// Тестируем чистый вывод JSON
echo "<h3>4. Тест чистого JSON вывода:</h3>";
ob_clean(); // Очищаем буфер вывода

// Имитируем get_all_progress.php
header('Content-Type: application/json');
if (!isset($_SESSION['user_id'])) {
    $response = ['error' => 'not_authenticated'];
} else {
    $stmt = $conn->prepare("SELECT lesson_key, points FROM user_progress WHERE user_id = ?");
    $stmt->bind_param("i", $_SESSION['user_id']);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $totalPoints = 0;
    $completedLessons = [];
    
    while ($row = $result->fetch_assoc()) {
        $completedLessons[] = $row['lesson_key'];
        $totalPoints += $row['points'];
    }
    
    $response = [
        'points' => $totalPoints,
        'completedLessons' => $completedLessons
    ];
}

echo json_encode($response, JSON_PRETTY_PRINT);
?>