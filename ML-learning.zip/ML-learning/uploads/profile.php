<?php
session_start();

$host = 'localhost';
$user = 'root';
$password = '';
$dbname = 'ml';

$conn = new mysqli($host, $user, $password, $dbname);
if ($conn->connect_error) {
    die("Ошибка подключения: " . $conn->connect_error);
}

if (!isset($_SESSION['user_id'])) {
    header("Location: login.html");
    exit();
}

$user_id = (int) $_SESSION['user_id']; 

$updateStmt = $conn->prepare("UPDATE users SET last_login = NOW() WHERE id = ?");
$updateStmt->bind_param("i", $user_id);
$updateStmt->execute();
$updateStmt->close();

$stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
if (!$stmt) {
    die("Ошибка подготовки запроса: " . $conn->error);
}
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result ? $result->fetch_assoc() : null;

if (!$user) {
    session_destroy();
    header("Location: ../login.html");
    exit();
}

$_SESSION['avatar'] = $user['avatar'] ?? '';
$_SESSION['first_name'] = $user['first_name'] ?? '';
$_SESSION['last_name'] = $user['last_name'] ?? '';

$initials = '?';
if (!empty($_SESSION['first_name']) && !empty($_SESSION['last_name'])) {
    $initials = mb_strtoupper(mb_substr($_SESSION['first_name'], 0, 1) . mb_substr($_SESSION['last_name'], 0, 1));
} elseif (!empty($_SESSION['first_name'])) {
    $initials = mb_strtoupper(mb_substr($_SESSION['first_name'], 0, 1));
}

// ВАЖНОЕ ИЗМЕНЕНИЕ: Улучшенная логика получения пути к аватару
$avatar_path = '';
$avatar_timestamp = $_SESSION['avatar_updated'] ?? time(); // Используем timestamp из сессии или текущее время

if (!empty($user['avatar'])) {
    $avatar_filename = basename($user['avatar']);
    $possible_path = __DIR__ . '/uploads/' . $avatar_filename;
    if (file_exists($possible_path)) {
        // ВАЖНОЕ ИЗМЕНЕНИЕ: Добавляем параметр версии для предотвращения кеширования
        $avatar_path = 'uploads/' . $avatar_filename . '?v=' . $avatar_timestamp;
    } else {
        $avatar_path = '';
    }
}

$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;800&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&family=Montserrat:wght@600&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;800&family=Montserrat:wght@600;700&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link rel="website icon" type="png" href="../img/icon2.png">
    <style>
        body {
            margin: 0;
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #313364 0%, #275f85 100%);
            color: white;
            position: relative;
            min-height: 100vh;
            overflow-x: hidden;
        }

        header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 25px 40px;
            background-color: rgba(37, 39, 77, 0.9);
            backdrop-filter: blur(10px);
            border-bottom: 2px solid #AAABB8;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .logo img {
            border-radius: 50%;
            margin-right: 10px;
            border: 2px solid #2E9CCA;
            box-shadow: 0 0 15px rgba(46, 156, 202, 0.4);
        }

        .logo span {
            font-size: 23px;
            font-weight: 600;
            font-family: 'Montserrat', sans-serif;
            color: #2E9CCA;
        }

        .profile-container {
            max-width: 800px;
            margin: 60px auto;
            background-color: rgba(70, 72, 102, 0.8);
            padding: 50px;
            border-radius: 25px;
            border: 2px solid #AAABB8;
            box-shadow: 0 15px 50px rgba(0, 0, 0, 0.3);
            text-align: center;
        }

        .avatar-container {
            position: relative;
            display: inline-block;
            margin-bottom: 30px;
        }

        .avatar {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            border: 4px solid #2E9CCA;
            box-shadow: 0 0 25px rgba(46, 156, 202, 0.4);
            object-fit: cover;
        }

        .edit-avatar {
            position: absolute;
            bottom: 0;
            right: 0;
            background: linear-gradient(45deg, #2E9CCA, #29648A);
            color: white;
            border: none;
            border-radius: 50%;
            width: 35px;
            height: 35px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .edit-avatar:hover {
            transform: scale(1.1);
            box-shadow: 0 0 15px rgba(46, 156, 202, 0.6);
        }

        .user-info h2 {
            font-size: 32px;
            font-weight: 700;
            margin-bottom: 10px;
            color: #2E9CCA;
            font-family: 'Montserrat', sans-serif;
        }

        .user-role {
            font-size: 18px;
            color: #AAABB8;
            margin-bottom: 25px;
            font-weight: 600;
        }

        .profile-stats {
            display: flex;
            justify-content: center;
            gap: 40px;
            margin: 30px 0;
        }

        .stat-item {
            text-align: center;
        }

        .stat-value {
            font-size: 28px;
            font-weight: 800;
            color: #2E9CCA;
            margin-bottom: 5px;
        }

        .stat-label {
            font-size: 16px;
            color: #AAABB8;
        }

        .profile-details {
            background-color: rgba(37, 39, 77, 0.6);
            padding: 25px;
            border-radius: 15px;
            margin-top: 30px;
            text-align: left;
        }

        .detail-item {
            display: flex;
            justify-content: space-between;
            padding: 12px 0;
            border-bottom: 1px solid rgba(170, 171, 184, 0.3);
        }

        .detail-item:last-child {
            border-bottom: none;
        }

        .detail-label {
            color: #AAABB8;
            font-weight: 600;
        }

        .detail-value {
            color: white;
            font-weight: 600;
        }

        .action-buttons {
            display: flex;
            justify-content: center;
            gap: 20px;
            margin-top: 40px;
        }

        .action-btn {
            padding: 12px 30px;
            border: none;
            border-radius: 15px;
            font-size: 16px;
            font-weight: 600;
            font-family: 'Montserrat', sans-serif;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-block;
        }

        .edit-btn {
            background: linear-gradient(45deg, #2E9CCA, #29648A);
            color: white;
        }

        .edit-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 25px rgba(46, 156, 202, 0.5);
        }

        .logout-btn {
            background: linear-gradient(45deg, #AAABB8, #464866);
            color: white;
        }

        .logout-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 25px rgba(170, 171, 184, 0.4);
        }

        .back-home {
            display: inline-block;
            margin-top: 25px;
            color: #2E9CCA;
            text-decoration: none;
            font-weight: 600;
            transition: all 0.3s ease;
            font-family: 'Montserrat', sans-serif;
        }

        .back-home:hover {
            transform: scale(1.05);
            text-decoration: underline;
        }

        @media (max-width: 768px) {
            .profile-container {
                padding: 30px 20px;
                margin: 40px 20px;
            }
            
            .avatar {
                width: 100px;
                height: 100px;
            }
            
            .profile-stats {
                gap: 20px;
                flex-wrap: wrap;
            }
            
            .stat-value {
                font-size: 24px;
            }
            
            .action-buttons {
                flex-direction: column;
                gap: 15px;
            }
            
            .action-btn {
                width: 100%;
            }
        }

        @media (max-width: 576px) {
            header {
                padding: 20px;
            }
            
            .user-info h2 {
                font-size: 26px;
            }
            
            .profile-details {
                padding: 20px;
            }
        }
        .avatar-default {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            background: linear-gradient(135deg, #4f46e5, #06b6d4);
            color: white;
            font-size: 42px;
            font-weight: bold;
            display: flex;
            align-items: center;
            justify-content: center;
            border: 4px solid #2E9CCA;
            box-shadow: 0 0 25px rgba(46, 156, 202, 0.4);
        }

        .delete-avatar {
    position: absolute;
    bottom: 0;
    left: 0;
    background: linear-gradient(45deg, #e63946, #9d0208);
    color: white;
    border: none;
    border-radius: 50%;
    width: 35px;
    height: 35px;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    transition: all 0.3s ease;
}

.delete-avatar:hover {
    transform: scale(1.1);
    box-shadow: 0 0 15px rgba(230, 57, 70, 0.6);
}

    </style>
</head>
<body>
<header>
    <div class="logo">
        <img src="../img/logtype.png" alt="Logo" width="50" height="50">
        <span class="topic">BilimAI</span>
    </div>
</header>

<div class="profile-container">
    <div class="avatar-container">
    <?php if (!empty($avatar_path)): ?>
        <!-- ВАЖНОЕ ИЗМЕНЕНИЕ: Используем $avatar_path который уже содержит параметр версии -->
        <img src="<?= $avatar_path ?>" alt="Пайдаланушы аватары" class="avatar" id="userAvatar">
    <?php else: ?>
        <div class="avatar avatar-default" id="userAvatar"><?= $initials ?></div>
    <?php endif; ?>

    <!-- Аватарды өзгерту формасы -->
    <form action="upload_avatar.php" method="POST" enctype="multipart/form-data" id="avatarForm">
        <label for="avatarInput" class="edit-avatar" title="Аватарды ауыстыру">
            <i class="fas fa-camera"></i>
        </label>
        <input type="file" name="avatar" id="avatarInput" accept="image/*" style="display: none;" onchange="document.getElementById('avatarForm').submit();">
    </form>

    <!-- Аватарды жою формасы -->
    <form action="delete_avatar.php" method="POST" id="deleteAvatarForm">
        <button type="submit" class="delete-avatar" title="Аватарды өшіру">
            <i class="fas fa-trash"></i>
        </button>
    </form>
</div>


    <div class="user-info">
        <h2><?= htmlspecialchars($user['first_name'] . ' ' . $user['last_name']) ?></h2>
        <div class="user-role">Пайдаланушы • BilimAI</div>
    </div>

    <div class="profile-details">
        <div class="detail-item">
            <span class="detail-label">Электронды пошта:</span>
            <span class="detail-value"><?= htmlspecialchars($user['email']) ?></span>
        </div>
        <div class="detail-item">
            <span class="detail-label">Телефон:</span>
            <span class="detail-value"><?= htmlspecialchars($user['phone'] ?? 'Көрсетілмеген') ?></span>
        </div>
        <div class="detail-item">
            <span class="detail-label">Тіркелу күні:</span>
            <span class="detail-value">
                <?= !empty($user['created_at']) ? date('d.m.Y', strtotime($user['created_at'])) : 'Көрсетілмеген'; ?>
            </span>
        </div>
        <div class="detail-item">
            <span class="detail-label">Қала:</span>
            <span class="detail-value"><?= htmlspecialchars($user['city'] ?? 'Көрсетілмеген') ?></span>
        </div>
    </div>

    <div class="action-buttons">
        <a href="edit_profile.php" class="action-btn edit-btn">Профильді өңдеу</a>
        <a href="../logout.php" class="action-btn logout-btn">Аккаунттан шығу</a>
    </div>

    <a href="../index1.php" class="back-home">← Басты бетке оралу</a>
</div>
<script>
const bc = new BroadcastChannel('avatar_channel');
bc.postMessage({ avatar: 'uploads/<?= $_SESSION['avatar'] ?>' });

localStorage.setItem('avatar_updated', JSON.stringify({ avatar: 'uploads/<?= $_SESSION['avatar'] ?>', t: Date.now() }));
</script>

</body>
</html>