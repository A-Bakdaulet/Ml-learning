<?php
session_start();

$host = 'localhost';
$user = 'root';
$password = '';
$dbname = 'ml';
$conn = new mysqli($host, $user, $password, $dbname);

if ($conn->connect_error) {
    die("Ошибка подключения: " . $conn->connect_error);
}

if (!isset($_SESSION['user_id'])) {
    header("Location: login.html");
    exit();
}

$user_id = $_SESSION['user_id'];

if (isset($_FILES['avatar']) && $_FILES['avatar']['error'] === UPLOAD_ERR_OK) {
    $file_tmp = $_FILES['avatar']['tmp_name'];
    $file_name = $_FILES['avatar']['name'];
    $file_size = $_FILES['avatar']['size'];
    $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));

    $allowed_ext = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
    if (!in_array($file_ext, $allowed_ext)) {
        $_SESSION['upload_error'] = "Ошибка: разрешены только JPG, PNG, GIF или WEBP.";
        header("Location: profile.php");
        exit();
    }

    if ($file_size > 3 * 1024 * 1024) {
        $_SESSION['upload_error'] = "Ошибка: файл слишком большой (максимум 3 МБ).";
        header("Location: profile.php");
        exit();
    }

    $upload_dir = __DIR__ . '/uploads/'; 
    if (!is_dir($upload_dir)) {
        mkdir($upload_dir, 0777, true);
    }

    // ВАЖНОЕ ИЗМЕНЕНИЕ: Используем одинаковое имя файла для пользователя
    $new_filename = 'avatar_' . $user_id . '.' . $file_ext;
    $upload_path = $upload_dir . $new_filename;

    // Удаляем старый аватар если он существует
    $old_avatar_pattern = $upload_dir . 'avatar_' . $user_id . '.*';
    $old_files = glob($old_avatar_pattern);
    foreach ($old_files as $old_file) {
        if (is_file($old_file)) {
            unlink($old_file);
        }
    }

    if (move_uploaded_file($file_tmp, $upload_path)) {
        // Обновляем запись в базе данных
        $stmt = $conn->prepare("UPDATE users SET avatar = ? WHERE id = ?");
        $stmt->bind_param("si", $new_filename, $user_id);
        
        if ($stmt->execute()) {
            // ВАЖНОЕ ИЗМЕНЕНИЕ: Добавляем timestamp к сессии для обновления кеша
            $_SESSION['avatar_updated'] = time();
            $_SESSION['avatar'] = $new_filename;
            $_SESSION['upload_success'] = "Аватар успешно обновлен!";
        } else {
            $_SESSION['upload_error'] = "Ошибка при обновлении базы данных.";
        }
        
        $stmt->close();

        header("Location: profile.php");
        exit();
    } else {
        $_SESSION['upload_error'] = "Ошибка при сохранении файла.";
        header("Location: profile.php");
        exit();
    }
} else {
    $_SESSION['upload_error'] = "Файл не загружен или произошла ошибка.";
    header("Location: profile.php");
    exit();
}

$conn->close();
?>