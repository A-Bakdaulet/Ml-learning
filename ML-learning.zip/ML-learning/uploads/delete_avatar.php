<?php
session_start();
$host = 'localhost';
$user = 'root';
$password = '';
$dbname = 'ml';

$conn = new mysqli($host, $user, $password, $dbname);
if ($conn->connect_error) {
    die("Ошибка подключения: " . $conn->connect_error);
}

if (!isset($_SESSION['user_id'])) {
    header("Location: login.html");
    exit();
}

$user_id = $_SESSION['user_id'];

// Получаем текущий аватар
$result = $conn->query("SELECT avatar FROM users WHERE id = $user_id");
$user = $result->fetch_assoc();

if (!empty($user['avatar'])) {
    $file_path = 'uploads/' . $user['avatar'];
    if (file_exists($file_path)) {
        unlink($file_path); // удаляем файл с сервера
    }

    // Удаляем ссылку на аватар из БД
    $conn->query("UPDATE users SET avatar = NULL WHERE id = $user_id");
}

header("Location: profile.php");
exit();
?>
