<?php
session_start();
require '../db.php'; // подключение к базе данных

// Получаем данные текущего пользователя
$user_id = $_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

$success = '';
$error = '';

// Обработка отправки формы
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $first_name = trim($_POST['first_name']);
    $last_name = trim($_POST['last_name']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    $city = trim($_POST['city']);

    // Опционально: изменение пароля
    $password = $_POST['password'] ?? '';
    $password_confirm = $_POST['password_confirm'] ?? '';

    if (!empty($password) && $password !== $password_confirm) {
        $error = "Парольдер сәйкес келмейді!";
    } else {
        // Обновляем данные
        if (!empty($password)) {
            $hashed = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("UPDATE users SET first_name=?, last_name=?, email=?, phone=?, city=?, password=? WHERE id=?");
            $stmt->execute([$first_name, $last_name, $email, $phone, $city, $hashed, $user_id]);
        } else {
            $stmt = $pdo->prepare("UPDATE users SET first_name=?, last_name=?, email=?, phone=?, city=? WHERE id=?");
            $stmt->execute([$first_name, $last_name, $email, $phone, $city, $user_id]);
        }
        $success = "Профиль сәтті жаңартылды!";
        // Обновляем переменную $user для отображения актуальных данных
        $user = array_merge($user, $_POST);
    }
}
?>

<!DOCTYPE html>
<html lang="kk">
<head>
    <meta charset="UTF-8">
    <title>Профильді өңдеу • BrainCode</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
<header>
    <div class="logo">
        <img src="../img/AI-logo.png" alt="Logo" width="50" height="50">
        <span class="topic">BrainCode</span>
    </div>
</header>

<div class="profile-container">
    <h2>Профильді өңдеу</h2>

    <?php if($success): ?>
        <div class="success-message"><?= $success ?></div>
    <?php endif; ?>
    <?php if($error): ?>
        <div class="error-message"><?= $error ?></div>
    <?php endif; ?>

    <form action="" method="POST" class="edit-profile-form">
        <div class="form-group">
            <label>Аты</label>
            <input type="text" name="first_name" value="<?= htmlspecialchars($user['first_name']) ?>" required>
        </div>
        <div class="form-group">
            <label>Тегі</label>
            <input type="text" name="last_name" value="<?= htmlspecialchars($user['last_name']) ?>" required>
        </div>
        <div class="form-group">
            <label>Электронды пошта</label>
            <input type="email" name="email" value="<?= htmlspecialchars($user['email']) ?>" required>
        </div>
        <div class="form-group">
            <label>Телефон</label>
            <input type="text" name="phone" value="<?= htmlspecialchars($user['phone'] ?? '') ?>">
        </div>
        <div class="form-group">
            <label>Қала</label>
            <input type="text" name="city" value="<?= htmlspecialchars($user['city'] ?? '') ?>">
        </div>
        <div class="form-group">
            <label>Жаңа пароль (қалаған жағдайда)</label>
            <input type="password" name="password">
        </div>
        <div class="form-group">
            <label>Парольді растау</label>
            <input type="password" name="password_confirm">
        </div>
        <button type="submit" class="action-btn edit-btn">Сақтау</button>
        <a href="profile.php" class="action-btn logout-btn">Болдырмау</a>
    </form>
</div>
</body>
</html>
