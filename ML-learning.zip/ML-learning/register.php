<?php
require 'vendor/autoload.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

header('Content-Type: application/json');


$host = 'localhost';
$user = 'root';
$password = '';
$dbname = 'ml';

$conn = new mysqli($host, $user, $password, $dbname);
if ($conn->connect_error) {
    echo json_encode(['success' => false, 'message' => 'Мәліметтер қорына қосылу кезінде қате пайда болды.']);
    exit();
}

$first_name = trim($_POST['first_name'] ?? '');
$last_name = trim($_POST['last_name'] ?? '');
$email = trim($_POST['email'] ?? '');
$password_raw = $_POST['password'] ?? '';


if (empty($first_name) || empty($last_name) || empty($email) || empty($password_raw)) {
    echo json_encode(['success' => false, 'message' => 'Барлық жолдарды толтырыңыз.']);
    exit();
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo json_encode(['success' => false, 'message' => 'Email дұрыс енгізілмеген.']);
    exit();
}

$stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$stmt->store_result();
if ($stmt->num_rows > 0) {
    echo json_encode(['success' => false, 'message' => 'Бұл email арқылы тіркелген пайдаланушы бар.']);
    exit();
}
$stmt->close();

$hashed_password = password_hash($password_raw, PASSWORD_DEFAULT);
$verification_code = bin2hex(random_bytes(16));
$is_verified = 0;

$stmt = $conn->prepare("INSERT INTO users (first_name, last_name, email, password, verification_code, is_verified) VALUES (?, ?, ?, ?, ?, ?)");
$stmt->bind_param("sssssi", $first_name, $last_name, $email, $hashed_password, $verification_code, $is_verified);

if (!$stmt->execute()) {
    echo json_encode(['success' => false, 'message' => 'Тіркелу кезінде қате пайда болды.']);
    exit();
}
$stmt->close();

$mail = new PHPMailer(true);
try {
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = 'bakdauletasylhan41@gmail.com';
    $mail->Password = 'ozci omrf efgh odjf';
    $mail->SMTPSecure = 'tls';
    $mail->Port = 587;

    $mail->setFrom('bakdauletasylhan41@gmail.com', 'BilimAI');
    $mail->addAddress($email, $first_name);

    $mail->CharSet = 'UTF-8';
    $mail->isHTML(true);
    $mail->Subject = 'Поштаңызды растаңыз';

    $verification_link = "http://localhost/ML-learning/verify_email.php?code=$verification_code";
    $mail->Body = "
        <h3>Сәлеметсіз бе, $first_name!</h3>
        <p>Өтінеміз, төмендегі сілтеме арқылы поштаңызды растаңыз:</p>
        <p><a href='$verification_link'>Поштаны растау</a></p>
        <p>Құрметпен, <b>BrainCode</b> командасы 💡</p>
    ";

    $mail->send();

    echo json_encode([
        'success' => true,
        'message' => "✅ Поштаны растаңыз! Біз $email мекенжайына хат жібердік."
    ]);

} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Хат жіберу кезінде қате пайда болды: ' . $mail->ErrorInfo
    ]);
}

$conn->close();
?>
