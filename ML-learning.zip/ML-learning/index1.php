<?php
session_start();

$host = 'localhost';
$user = 'root';
$password = '';
$dbname = 'ml';

$conn = new mysqli($host, $user, $password, $dbname);
if ($conn->connect_error) {
    die("Ошибка подключения: " . $conn->connect_error);
}

if (!isset($_SESSION['user_id'])) {
    header("Location: login.html");
    exit();
}

$user_id = (int) $_SESSION['user_id'];

// Обновляем время последнего визита
$updateStmt = $conn->prepare("UPDATE users SET last_login = NOW() WHERE id = ?");
$updateStmt->bind_param("i", $user_id);
$updateStmt->execute();
$updateStmt->close();

// Получаем данные пользователя
$stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result ? $result->fetch_assoc() : null;

if (!$user) {
    session_destroy();
    header("Location: login.html");
    exit();
}

// Сохраняем данные в сессию
$_SESSION['avatar'] = $user['avatar'] ?? '';
$_SESSION['first_name'] = $user['first_name'] ?? '';
$_SESSION['last_name'] = $user['last_name'] ?? '';

// Формируем инициалы
$initials = '?';
if (!empty($_SESSION['first_name']) && !empty($_SESSION['last_name'])) {
    $initials = mb_strtoupper(mb_substr($_SESSION['first_name'],0,1) . mb_substr($_SESSION['last_name'],0,1));
} elseif (!empty($_SESSION['first_name'])) {
    $initials = mb_strtoupper(mb_substr($_SESSION['first_name'],0,1));
}

$avatar_path = '';
$avatar_timestamp = $_SESSION['avatar_updated'] ?? time(); 

if (!empty($user['avatar'])) {
    $avatar_filename = basename($user['avatar']);
    $possible_path = __DIR__ . '/uploads/' . $avatar_filename;
    if (file_exists($possible_path)) {
        $avatar_path = 'uploads/' . $avatar_filename . '?v=' . $avatar_timestamp;
    }
}

$stmt->close();
$conn->close();
?>


<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BilimAI</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;800&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&family=Montserrat:wght@600&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;800&family=Montserrat:wght@600;700&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link rel="website icon" type="ico" href="img/icon2.png">
    <style>
        body {
        margin: 0;
        font-family: 'Inter', sans-serif;
        background: linear-gradient(135deg, #313364 0%, #275f85 100%);
        color: white;
        position: relative;
        min-height: 100vh;
        overflow-x: hidden;
        }

        header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 25px 40px;
        background-color: rgba(37, 39, 77, 0.9);
        backdrop-filter: blur(10px);
        border-bottom: 2px solid #AAABB8;
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
        }

        .logo {
        display: flex;
        align-items: center;
        gap: 10px;
        }

        .logo img {
        border-radius: 50%;
        margin-right: 10px;
        border: 2px solid #2E9CCA;
        box-shadow: 0 0 15px rgba(46, 156, 202, 0.4);
        }

        .logo span {
        font-size: 23px;
        font-weight: 600;
        font-family: 'Montserrat', sans-serif;
        color: #2E9CCA;
        }

        .buttons {
            display: flex;
            gap: 10px;
        }
        
        .buttons button,
        .auth-btn {
        padding: 10px 20px;
        border: none;
        border-radius: 25px;
        font-weight: 600;
        cursor: pointer;
        font-family: 'Montserrat', sans-serif;
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.3);
        transition: all 0.3s ease;
        }
        
        .login {
        background: linear-gradient(45deg, #2E9CCA, #29648A);
        color: white;
        font-size: 15px;
        transform: translateY(0);
        }
        .login:hover{
        transform: translateY(-3px) scale(1.05);
        box-shadow: 0 8px 25px rgba(46, 156, 202, 0.5);
        }

        .register {
        background: linear-gradient(45deg, #AAABB8, #464866);
        color: white;
        font-size: 15px;
        transform: translateY(0);
        }
        .register:hover{
        transform: translateY(-3px) scale(1.05);
        box-shadow: 0 8px 25px rgba(170, 171, 184, 0.4);
        }

        .main-content {
        text-align: center;
        padding: 80px 20px 60px;
        max-width: 800px;
        margin: 0 auto;
        }

        .main-content h1 {
        font-size: 48px;
        font-weight: 800;
        color: white;
        margin-bottom: 20px;
        background: linear-gradient(45deg, #2E9CCA, #AAABB8);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
        }

        .main-content p {
        font-size: 20px;
        color: #AAABB8;
        margin-top: 10px;
        line-height: 1.6;
        }
        
        .about-section {
        max-width: 800px;
        margin: 60px auto 40px;
        background-color: rgba(70, 72, 102, 0.7);
        padding: 40px;
        border-radius: 20px;
        border: 2px solid #2E9CCA;
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.2);
        }

        .about-title {
        font-size: 28px;
        font-weight: 700;
        margin-bottom: 20px;
        color: #2E9CCA;
        }

        .about-description {
        font-size: 18px;
        line-height: 1.7;
        color: #AAABB8;
        }

        .goal-section {
        max-width: 800px;
        margin: 40px auto;
        background-color: rgba(70, 72, 102, 0.7);
        padding: 40px;
        border-radius: 20px;
        border: 2px solid #2E9CCA;
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.2);
        }

        .goal-title {
        font-size: 28px;
        font-weight: 700;
        margin-bottom: 20px;
        color: #2E9CCA;
        }

        .goal-description {
        font-size: 18px;
        line-height: 1.7;
        color: #AAABB8;
        }
        
        .p1text1 {
            position: absolute;
            top: 30px;
            left: 50%;
            transform: translateX(-50%);
            display: flex;
            align-items: center;
            flex-wrap: wrap;
            justify-content: center;
            z-index: 10;
            gap: 20px;
        }

        .nav-button {
            cursor: pointer;
            border-radius: 15px;
            transition: all 0.3s ease;
            display: inline-block;
            position: relative;
            font-size: 21px;
            padding: 10px 20px;
            color: #ffffff;
            text-decoration: none;
            font-size: 18px;
            font-family: 'Montserrat', sans-serif;
            background: rgba(70, 72, 102, 0.5);
            border: 2px solid rgba(170, 171, 184, 0.3);
        }

        .nav-button:hover {
        background-color: rgba(46, 156, 202, 0.3);
        transform: translateY(-3px) scale(1.05);
        color: white;
        border-color: #2E9CCA;
        }

        .dropdown-container {
        position: relative;
        display: inline-block;
        margin-right: 30px;
        }

        .lesson-dropdown {
        position: absolute;
        top: 100%;
        left: -20px;
        margin-top: 10px;
        background-color: rgba(70, 72, 102, 0.8);
        border: 2px solid #2E9CCA;
        padding: 15px;
        border-radius: 15px;
        z-index: 1000;
        display: flex;
        flex-direction: column;
        gap: 12px;
        width: 160px;
        opacity: 0;
        visibility: hidden;
        transition: opacity 0.3s, visibility 0.3s, transform 0.3s;
        transform: translateY(-10px);
        }

        .lesson-dropdown.show {
        opacity: 1;
        visibility: visible;
        transform: translateY(0);
        }

        .lesson-dropdown div {
        color: rgb(211, 196, 196);
        cursor: pointer;
        padding: 8px 12px;
        transition: all 0.3s;
        font-size: 18px;
        font-family: 'Montserrat', sans-serif;
        background: rgba(37, 39, 77, 0.5);
        border-radius: 8px;
        text-align: center;
        border: 1px solid rgba(170, 171, 184, 0.3);
        }

        .lesson-dropdown div:hover {
        background-color: #2E9CCA;
        color: white;
        transform: scale(1.05);
        border-color: #2E9CCA;
        }
        
        .transition-overlay {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: linear-gradient(135deg, #2E9CCA, #29648A, #AAABB8);
        opacity: 0;
        pointer-events: none;
        z-index: 9999;
        transition: opacity 0.6s ease-in-out;
        }

        .transition-overlay.show {
        opacity: 1;
        pointer-events: auto;
        }

        .fade-out {
        animation: fadeOut 0.5s ease forwards;
        }

        @keyframes fadeOut {
        from { opacity: 1; }
        to { opacity: 0; }
        }

        body.load-in {
        animation: fadeIn 0.5s ease forwards;
        }

        @keyframes fadeIn {
        from { opacity: 0; }
        to { opacity: 1; }
        }

        /* Mobile menu */
        .mobile-menu-btn {
        display: none;
        background: linear-gradient(45deg, #2E9CCA, #29648A);
        border: none;
        color: white;
        font-size: 24px;
        cursor: pointer;
        position: absolute;
        top: 50px;
        right: 30px;
        z-index: 100;
        width: 50px;
        height: 50px;
        border-radius: 25px;
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.3);
        }

        /* Responsive adjustments */
        @media (max-width: 1200px) {
        .p1text1 {
            right: 20px;
        }
        }

        @media (max-width: 992px) {
        .p1text1 {
            display: none;
            flex-direction: column;
            align-items: center;
            background-color: rgba(70, 72, 102, 0.8);
            padding: 20px;
            right: 0;
            top: 120px;
            width: calc(100% - 40px);
            margin: 0 20px;
            border-radius: 20px;
            border: 2px solid #AAABB8;
        }
        
        .p1text1.active {
            display: flex;
        }
        
        .nav-button, .dropdown-container {
            margin: 10px 0;
            width: 100%;
            text-align: center;
        }
        
        .mobile-menu-btn {
            display: block;
        }
        }

        @media (max-width: 768px) {
        .main-content h1 {
            font-size: 36px;
        }
        
        .main-content p {
            font-size: 18px;
        }
        
        .about-section, .goal-section {
            padding: 30px;
            margin: 40px auto;
        }
        
        .about-title, .goal-title {
            font-size: 24px;
        }
        }

        @media (max-width: 576px) {
        header {
            padding: 20px;
        }
        
        .main-content {
            padding: 60px 15px 40px;
        }
        
        .main-content h1 {
            font-size: 28px;
        }
        
        .main-content p {
            font-size: 16px;
        }
        
        .buttons button {
            padding: 8px 16px;
            font-size: 14px;
        }
        }
        
        .user-auth-container {
        display: flex;
        align-items: center;
        gap: 20px;
        margin-left: 30px;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .user-auth-container b{
            font-size: 22px;
        }

        .user-icon-wrapper {
        background: rgba(70, 72, 102, 0.5);
        padding: 10px;
        border-radius: 50%;
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.3);
        cursor: default;
        transition: all 0.3s ease;
        border: 2px solid #AAABB8;
        }

        .user-icon-wrapper:hover {
        box-shadow: 0 8px 25px rgba(46, 156, 202, 0.4);
        transform: scale(1.15);
        background: rgba(46, 156, 202, 0.3);
        border-color: #2E9CCA;
        }

        .user-icon {
        display: block;
        filter: drop-shadow(0 0 5px rgba(255, 255, 255, 0.8));
        }

        .auth-btn {
        padding: 10px 24px;
        border-radius: 25px;
        border: 2px solid rgba(170, 171, 184, 0.7);
        background: rgba(70, 72, 102, 0.5);
        color: white;
        font-weight: 600;
        font-size: 15px;
        cursor: pointer;
        transition: all 0.3s ease;
        box-shadow: 0 4px 15px rgba(0,0,0,0.3);
        user-select: none;
        margin-right: 10px;
        }

        .auth-btn:hover {
        background: rgba(46, 156, 202, 0.4);
        border-color: #2E9CCA;
        box-shadow: 0 8px 25px rgba(46, 156, 202, 0.4);
        color: white;
        transform: translateY(-2px);
        }
        
        footer {
            background: rgba(3, 3, 3, 0.3);
            margin-top: 8rem;
            padding: 3rem 6rem;
            border-top: 1px solid var(--border-color);
            font-size: 15px;
        }

        .footer-content {
            display: flex;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 2rem;
        }

        .footer-section h3 {
            font-size: 1.5rem;
            margin-bottom: 1.5rem;
            color: #2E9CCA;
            
        }
        .footer-section p{
            max-width: 500px;

        }
        .footer-section p, .footer-section a {
            color: var(--text-gray);
            margin-bottom: 0.8rem;
            display: block;
            text-decoration: none;
            line-height: 1.7;
            color: #AAABB8;
            transition: all 0.3s ease;
        }

        .footer-section a:hover {
            color: var(--hover-color);
            transform: scale(1.05);
        }

        .social-links {
            display: flex;
            gap: 1rem;
            margin-top: 1rem;
        }

        .social-links a {
            color: var(--text-gray);
            font-size: 1.5rem;
            transition: color 0.3s ease;
        }
        .social-links a:hover{
            transform: scale(1.05);
            color: #AAABB8;;
        }
        .logout-btn {
            display: inline-block;
            padding: 8px;
            border-radius: 50%;
            background-color: #f44336; 
            transition: background 0.3s ease;
        }

        .logout-btn img {
            vertical-align: middle;
        }

        .logout-btn:hover {
            background-color: #d32f2f; 
        }
        .avatar-container {
            position: relative;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .avatar {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            object-fit: cover;
            border: 4px solid #2E9CCA;
            box-shadow: 0 0 25px rgba(46, 156, 202, 0.4);
            transition: transform 0.3s ease;
            
        }
        .avatar:hover{
            transform: scale(1.05);
        }

        .avatar-default {
            background: linear-gradient(135deg, #4f46e5, #06b6d4);
            color: white;
            font-size: 18px;
            font-weight: bold;
            display: flex;
            align-items: center;
            justify-content: center;
            text-decoration: none;
        }

        @media (max-width: 992px) {
            .avatar {
                width: 80px;
                height: 80px;
                font-size: 28px;
            }
        }

        .logo {
        display: flex;
        align-items: center;
        gap: 10px; 
        }

        .logo-img {
        width: 70px;
        height: 70px;
        object-fit: cover; 
        border-radius: 50%; 
        border: 2px solid white; 
        box-shadow: 0 0 8px rgba(0, 0, 0, 0.2); 
        }
    </style>
    </head>

    <body>
    <div class="transition-overlay" id="transition-overlay"></div>

    <header>
        <div class="logo">
        <img src="img/logtype.png" alt="Logo" class="logo-img" width="70" height="70">
        <span class="topic">BilimAI</span>
        </div>
        <button class="mobile-menu-btn" id="mobile-menu-btn">☰</button>

        <div class="p1text1" id="nav-container">
        <span class="nav-button" id="about-btn">Біз туралы</span>
        <span class="nav-button" id="goal-btn">Мақсат</span>
        <span class="nav-button" id="contact-btn">Байланыс</span>
        <div class="dropdown-container" id="lessons-container">
            <span class="nav-button" id="lessons-btn">Сабақтар</span>
            <div id="lesson-dropdown" class="lesson-dropdown">
            <div onclick="openLesson('python')">Python</div>
            <div onclick="openLesson('vision')">Визуализация</div>
            <div onclick="openLesson('regress')">Регрессия</div>
            <div onclick="openLesson('alg')">Алгоритдер</div>
            <div onclick="openLesson('rate')">Бағалау</div>
            <div onclick="openLesson('practice')">Практика</div>
            <div onclick="openLesson('project')">Жоба</div>
            </div>
        </div>
        </div>

        <div class="user-auth-container">
        <div class="avatar-container">
            <a href="uploads/profile.php" style="text-decoration: none">
                <?php if (!empty($avatar_path)): ?>
                    <img src="<?= $avatar_path ?>" alt="Аватар пользователя" class="avatar" id="userAvatar">
                <?php else: ?>
                    <div class="avatar avatar-default" id="userAvatar"><?= $initials ?></div>
                <?php endif; ?>
            </a>
        </div>

            <b><?= htmlspecialchars($_SESSION['first_name']) ?></b>
            <a href="logout.php" class="logout-btn">
                <img src="https://cdn-icons-png.flaticon.com/512/9297/9297112.png" alt="Выход" width="32">
            </a>
        </div>
    </header>

    <div class="main-content">
        <h1>BilimAI платформасына қош келдіңіз!</h1>
        <p>Біз студенттер мен жас мамандарға машиналық оқытуды (Machine Learning) қарапайым және түсінікті түрде үйренуге көмектесеміз.</p>
    </div>
    
    <!-- Сертификат и поздравление будут показаны только через JavaScript когда все уроки завершены -->
    <div id="congrats-message" style="display: none; text-align: center; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; margin: 50px 0;">
        <h1 style="font-size:48px; color:#ff9800; margin-bottom:20px;">🎉 Құттықтаймыз! 🎉</h1>
        <p style="font-size:22px; color: #AAABB8; margin:15px 0;">
            Сіз BilimAI платформасында барлық сабақтарды сәтті аяқтадыңыз! 🌟
        </p>
    </div>

    <!-- Кнопка для сертификата -->
    <div style="display: none; text-align:center; margin:30px 0;" id="certificate-button-container">
        <button id="show-certificate-btn" style="
            padding: 12px 30px;
            font-size: 18px;
            background: #4CAF50;
            color: white;
            border: none;
            border-radius: 10px;
            cursor: pointer;
            transition: 0.3s;
        " onmouseover="this.style.background='#45a049'" onmouseout="this.style.background='#4CAF50'">
            Сіздің сертификатыңыз
        </button>
    </div>

    <!-- Сертификат -->
    <div id="certificate-container" style="display:none; text-align:center; margin:50px 0;">
        <div id="certificate" style="
            width: 750px;
            margin: 0 auto;
            color: black;
            padding: 50px 50px;
            border: 10px solid #4CAF50;
            border-radius: 25px;
            background: linear-gradient(145deg, #ffffff, #e8f5e9);
            box-shadow: 0 0 25px rgba(0,0,0,0.2);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            position: relative;
            overflow: hidden;
            text-align: center;
        ">
            <!-- Водяной знак -->
            <div style="
                position: absolute;
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%) rotate(-25deg);
                font-size: 120px;
                color: rgba(0, 0, 0, 0.05);
                font-weight: bold;
                pointer-events: none;
                user-select: none;
            ">BilimAI</div>

            <h1 style="color:#4CAF50; margin-bottom:20px; font-size:48px; font-weight:bold;">🎓 СЕРТИФИКАТ</h1>
            <p style="font-size:20px; margin:25px 0;">Бұл сертификат берілді</p>
            <p style="font-size:22px; margin:10px 0; font-weight:bold; color:#2e7d32;">
                <?= htmlspecialchars($_SESSION['first_name']) ?> <?= htmlspecialchars($_SESSION['last_name']) ?>
            </p>
            <p style="font-size:18px; margin:25px 0; line-height:1.6;">
                Сіз BilimAI платформасында <b>«Machine Learning және Data Science»</b> курсын сәтті аяқтадыңыз. 
                Бұл курс сізге келесі дағдыларды меңгеруге мүмкіндік берді:
            </p>
            <ul style="text-align:left; font-size:16px; margin:20px 0; line-height:1.5; display:inline-block;">
                <li>Python бағдарламалау негіздері</li>
                <li>Деректерді талдау және өңдеу (Pandas, NumPy)</li>
                <li>Деректерді визуализациялау (Matplotlib)</li>
                <li>Машиналық оқыту алгоритмдерін қолдану (KNN, Decision Tree, Регрессия)</li>
                <li>Нақты жобаларды іске асыру</li>
                <li>Модельдерді бағалау және оңтайландыру</li>
            </ul>
            <div style="margin:30px 0; font-size:16px; display:flex; justify-content:space-between; padding: 0 20px;">
                <span>Курс ұзақтығы: 34 апта</span>
                <span>Берілген күні: <?= date('d.m.Y') ?></span>
            </div>
            <div style="margin-top:20px; font-size:18px; display:flex; justify-content:center; align-items:center; gap:15px;">
                <span>BilimAI платформасы</span>
            </div>
            <button id="download-pdf" style="
                margin-top:30px;
                padding:12px 30px;
                font-size:16px;
                background:#4CAF50;
                color:white;
                border:none;
                border-radius:10px;
                cursor:pointer;
                transition:0.3s;
            " onmouseover="this.style.background='#45a049'" onmouseout="this.style.background='#4CAF50'">
                PDF ретінде жүктеу
            </button>
        </div>
    </div>
    
    <div class="about-section">
        <h2 class="about-title">БІЗ ТУРАЛЫ</h2>
        <p class="about-description">
        BrainCode – бұл заманауи технологияларды меңгергісі келетіндерге арналған білім беру платформасы. Біз сізге Machine Learning негіздерін, жасанды интеллект алгоритмдерін және деректерді талдау әдістерін үйретеміз. 
        Платформада сабақтар, бейнежазбалар, интерактивті тапсырмалар мен нақты жобалар бар.
        </p>
    </div>

    <div class="goal-section">
        <h2 class="goal-title">БІЗДІҢ МАҚСАТ</h2>
        <p class="goal-description">
        Біз әрбір адамға жасанды интеллект пен машиналық оқыту саласында білім алуға мүмкіндік бергіміз келеді. 
        Біздің мақсатымыз – келешектің IT-мамандарын тәрбиелеу және білімді барлығына қолжетімді ету.
        </p>
    </div>
    
    <footer id="footer-section">
    <div class="container">
        <div class="footer-content">
            <div class="footer-section">
                <h3>BilimAI</h3>
                <p>Бағдарламалау мен технологияны үйренудің заманауи платформасы. Ойлауды дамыт, код арқылы болашағыңды құр!</p>
                <div class="social-links">
                    <a href="#"><i class="fab fa-youtube"></i></a>
                    <a href="#"><i class="fab fa-telegram"></i></a>
                    <a href="#"><i class="fab fa-instagram"></i></a>
                </div>
            </div>
            <div class="footer-section">
                <h3>Сілтемелер</h3>
                <a href="#">Басты бет</a>
                <a href="#">Біз туралы</a>
                <a href="#">Сабақтар</a>
                <a href="#">Мақсат</a>
            </div>
            <div class="footer-section">
                <h3>Байланыс</h3>
                <p>support@braincode.edu</p>
                <p>+7 (776) 355-83-76</p>
                <p>Алматы қ., Қазақстан</p>
            </div>
        </div>
        <div class="copyright" style="color: #e2e8f0;">
            &copy; 2025 BilimAI. Барлық құқықтар қорғалған.
        </div>
    </div>
</footer>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
<script>
// Проверка завершения всех уроков
async function checkAllLessonsCompleted() {
    try {
        const response = await fetch('get_all_progress.php');
        const data = await response.json();
        
        // Общее количество уроков в системе
        const totalLessons = 41; // Python:4 + Vision:8 + Regress:8 + Alg:4 + Rate:4 + Practice:12 + Project:1
        
        if (data.completedLessons && data.completedLessons.length >= totalLessons) {
            // Показываем поздравление и кнопку сертификата
            document.getElementById('congrats-message').style.display = 'block';
            document.getElementById('certificate-button-container').style.display = 'block';
        }
    } catch (error) {
        console.error('Ошибка при проверке прогресса:', error);
    }
}

// Основная функция при загрузке страницы
document.addEventListener('DOMContentLoaded', () => {
    document.body.classList.add("loaded");

    // Проверяем завершены ли все уроки
    checkAllLessonsCompleted();

    // Обработчики для сертификата
    const showBtn = document.getElementById('show-certificate-btn');
    const certContainer = document.getElementById('certificate-container');
    const downloadBtn = document.getElementById('download-pdf');

    if (showBtn && certContainer) {
        showBtn.addEventListener('click', () => {
            certContainer.style.display = certContainer.style.display === 'none' ? 'block' : 'none';
        });
    }

    if (downloadBtn) {
        downloadBtn.addEventListener('click', () => {
            const { jsPDF } = window.jspdf;
            const certificate = document.getElementById('certificate');
            if (certificate) {
                html2canvas(certificate, { scale: 2 }).then(canvas => {
                    const imgData = canvas.toDataURL('image/png');
                    const pdf = new jsPDF('p', 'mm', 'a4');
                    const imgProps = pdf.getImageProperties(imgData);
                    const pdfWidth = pdf.internal.pageSize.getWidth() - 20;
                    const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;
                    pdf.addImage(imgData, 'PNG', 10, 10, pdfWidth, pdfHeight);
                    pdf.save('certificate.pdf');
                });
            }
        });
    }

    // Остальные обработчики навигации
    const mobileMenuBtn = document.getElementById('mobile-menu-btn');
    const navContainer = document.getElementById('nav-container');
    
    mobileMenuBtn.addEventListener('click', () => {
        navContainer.classList.toggle('active');
    });

    document.getElementById("goal-btn").addEventListener("click", () => {
        document.querySelector(".about-section").scrollIntoView({ behavior: "smooth" });
        navContainer.classList.remove('active');
    });
    
    document.getElementById("about-btn").addEventListener("click", () => {
        document.querySelector(".about-section").scrollIntoView({ behavior: "smooth" });
        navContainer.classList.remove('active');
    });

    document.getElementById("contact-btn").addEventListener("click", () => {
        document.querySelector(".footer-section").scrollIntoView({ behavior: "smooth" });
        navContainer.classList.remove('active');
    });

    const container = document.getElementById("lessons-container");
    const dropdown = document.getElementById("lesson-dropdown");
    let timeout;

    container.addEventListener("mouseenter", () => {
        clearTimeout(timeout);
        dropdown.classList.add("show");
    });

    container.addEventListener("mouseleave", (e) => {
        timeout = setTimeout(() => {
        if (!dropdown.contains(e.relatedTarget)) {
            dropdown.classList.remove("show");
        }
        }, 200);
    });

    dropdown.addEventListener("mouseenter", () => {
        clearTimeout(timeout);
        dropdown.classList.add("show");
    });

    dropdown.addEventListener("mouseleave", () => {
        dropdown.classList.remove("show");
    });

    document.addEventListener('click', (e) => {
        if (!container.contains(e.target) && !dropdown.contains(e.target)) {
        dropdown.classList.remove('show');
        }
    });
});

window.addEventListener("pageshow", (event) => {
    const overlay = document.getElementById("transition-overlay");
    if (overlay) {
        overlay.classList.remove("show");
    }
});

function openLesson(classNum) {
    const overlay = document.getElementById("transition-overlay");
    overlay.classList.add("show");
    setTimeout(() => {
        window.location.href = `lessons/lesson_${classNum}.html`;
    }, 500);
}
window.openLesson = openLesson;
</script>

<?php if (!empty($avatar)): ?>
<script>
const bc = new BroadcastChannel('avatar_channel');
bc.postMessage({ avatar: 'uploads/<?= $_SESSION['avatar'] ?>' });
localStorage.setItem('avatar_updated', JSON.stringify({ avatar: 'uploads/<?= $_SESSION['avatar'] ?>', t: Date.now() }));
</script>
<?php endif; ?>

</body>
</html>