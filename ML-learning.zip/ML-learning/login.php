<?php
session_start();
include 'db.php';

header('Content-Type: application/json');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    $stmt = $conn->prepare("SELECT * FROM users WHERE email=?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();

        if ($user['is_verified'] != 1) {
            echo json_encode([
                "success" => false,
                "message" => "Кіру үшін электрондық поштаңызды растаңыз."
            ]);
            exit();
        }

        if (password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['first_name'] = $user['first_name'];
            $_SESSION['last_name'] = $user['last_name'];
            $_SESSION['email'] = $user['email'];

            echo json_encode([
                "success" => true,
                "redirect" => "index1.php"
            ]);
            exit();
        } else {
            echo json_encode([
                "success" => false,
                "message" => "Қате құпиясөз."
            ]);
            exit();
        }
    } else {
        echo json_encode([
            "success" => false,
            "message" => "Мұндай электрондық пошта табылмады."
        ]);
        exit();
    }
}
?>
