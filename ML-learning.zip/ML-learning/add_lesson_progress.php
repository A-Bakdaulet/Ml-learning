<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'error' => 'Пользователь не авторизован']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
$lesson_id = $input['lesson_id'] ?? '';
$points = $input['points'] ?? 0;
$user_id = $_SESSION['user_id'];

try {
    // Проверяем существующую запись
    $check_sql = "SELECT id FROM user_progress WHERE user_id = ? AND lesson_key = ?";
    $check_stmt = $conn->prepare($check_sql);
    $check_stmt->bind_param("is", $user_id, $lesson_id);
    $check_stmt->execute();
    $result = $check_stmt->get_result();
    
    if ($result->num_rows > 0) {
        // Урок уже завершен
        echo json_encode([
            'success' => true, 
            'already_completed' => true,
            'message' => 'Сабақ бұрын аяқталған. Ұпайлар қайта есептелмейді.'
        ]);
    } else {
        // Создаем новую запись
        $insert_sql = "INSERT INTO user_progress (user_id, lesson_key, points) VALUES (?, ?, ?)";
        $insert_stmt = $conn->prepare($insert_sql);
        $insert_stmt->bind_param("isi", $user_id, $lesson_id, $points);
        
        if ($insert_stmt->execute()) {
            // Обновляем общую статистику пользователя
            $update_user_sql = "
                UPDATE users 
                SET 
                    overall_points = (
                        SELECT COALESCE(SUM(points), 0) 
                        FROM user_progress 
                        WHERE user_id = ?
                    ),
                    completed_lessons = (
                        SELECT COUNT(DISTINCT lesson_key) 
                        FROM user_progress 
                        WHERE user_id = ?
                    ),
                    last_activity = CURRENT_TIMESTAMP
                WHERE id = ?
            ";
            $update_user_stmt = $conn->prepare($update_user_sql);
            $update_user_stmt->bind_param("iii", $user_id, $user_id, $user_id);
            $update_user_stmt->execute();
            
            echo json_encode([
                'success' => true, 
                'already_completed' => false,
                'message' => 'Сабақ сәтті аяқталды! Сіз ' . $points . ' ұпай жинадыңыз.'
            ]);
        } else {
            echo json_encode(['success' => false, 'error' => 'Ошибка сохранения: ' . $conn->error]);
        }
    }
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => 'Исключение: ' . $e->getMessage()]);
}
?>