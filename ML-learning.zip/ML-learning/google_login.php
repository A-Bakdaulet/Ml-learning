<?php
require_once __DIR__ . '/vendor/autoload.php';
session_start();

$client = new Google_Client();
$client->setClientId('1051354821833-9lficesgqsmb4oe44j6e3vnhkaqir1vd.apps.googleusercontent.com');
$client->setClientSecret('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');
$client->setRedirectUri('http://localhost/ML-learning/google_login.php');
$client->addScope('email');
$client->addScope('profile');

try {
    if (!isset($_GET['code'])) {
        $authUrl = $client->createAuthUrl();
        header('Location: ' . filter_var($authUrl, FILTER_SANITIZE_URL));
        exit();
    }

    $token = $client->fetchAccessTokenWithAuthCode($_GET['code']);

    if (!is_array($token)) {
        throw new Exception("Google API қате жауап қайтарды. Мүмкін, cURL немесе SSL баптаулары дұрыс емес.");
    }

    if (isset($token['error'])) {
        throw new Exception("Авторизация қатесі: " . ($token['error_description'] ?? $token['error']));
    }

    $client->setAccessToken($token);

    $oauth = new Google_Service_Oauth2($client);
    $userInfo = $oauth->userinfo->get();

    $_SESSION['first_name'] = $userInfo->givenName;
    $_SESSION['last_name']  = $userInfo->familyName;
    $_SESSION['email']      = $userInfo->email;

    header('Location: index1.php');
    exit();

} catch (Exception $e) {
    echo "<h2>Google арқылы авторизация кезінде қате орын алды:</h2>";
    echo "<pre>" . htmlspecialchars($e->getMessage()) . "</pre>";
    echo "<h3>Қате туралы толық ақпарат (trace):</h3>";
    echo "<pre>" . htmlspecialchars($e->getTraceAsString()) . "</pre>";
    exit();
}
?>
