<?php
session_start();
require 'db.php';

function showMessage($title, $message, $success = true) {
    $color = $success ? 'green' : 'red';
    echo "
    <html>
    <head>
        <meta http-equiv='refresh' content='5;url=index1.php'>
        <style>
            body {
                font-family: Arial, sans-serif;
                background-color: #f8f8f8;
                display: flex;
                justify-content: center;
                align-items: center;
                height: 100vh;
            }
            .message {
                background: #fff;
                padding: 30px;
                border-radius: 10px;
                box-shadow: 0 0 15px rgba(0,0,0,0.2);
                text-align: center;
                max-width: 400px;
            }
            h2 {
                color: $color;
            }
        </style>
    </head>
    <body>
        <div class='message'>
            <h2>$title</h2>
            <p>$message</p>
            <p>Бірнеше секундтан кейін сіз негізгі бетке бағытталасыз...</p>
        </div>
    </body>
    </html>
    ";
    exit;
}

if (isset($_GET['code'])) {
    $token = $_GET['code'];

    $sql = "SELECT id, first_name, last_name FROM users WHERE verification_code = ? AND is_verified = 0";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $token);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $user = $result->fetch_assoc();

        $update = "UPDATE users SET is_verified = 1, verification_code = NULL WHERE id = ?";
        $stmt_update = $conn->prepare($update);
        $stmt_update->bind_param("i", $user['id']);
        $stmt_update->execute();

        $_SESSION['user_name'] = $user['first_name'] . ' ' . $user['last_name'];

        showMessage("✅ Пошта расталды!", "Сіз аккаунтыңызды сәтті белсендірдіңіз.");
    } else {
        showMessage("❌ Қате", "Сілтеме жарамсыз немесе бұрын пайдаланылған.", false);
    }
} else {
    showMessage("❌ Қате", "Растау коды көрсетілмеген.", false);
}
?>
