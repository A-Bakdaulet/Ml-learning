<?php
session_start();
require 'db.php';

header('Content-Type: application/json'); // возвращаем JSON

if (!isset($_SESSION['user_id'])) {
    echo json_encode(["error" => "not_logged_in"]);
    exit;
}

$user_id = $_SESSION['user_id'];
$lesson_key = $_POST['lesson_key'] ?? '';
$points = intval($_POST['points'] ?? 0);
$completed = intval($_POST['completed'] ?? 0);

// Проверка на пустой lesson_key
if (empty($lesson_key)) {
    echo json_encode(["error" => "lesson_key_empty"]);
    exit;
}

// Подготовленный запрос с ON DUPLICATE KEY
$stmt = $conn->prepare("
    INSERT INTO user_progress (user_id, lesson_key, points, completed)
    VALUES (?, ?, ?, ?)
    ON DUPLICATE KEY UPDATE
        points = VALUES(points),
        completed = VALUES(completed),
        updated_at = CURRENT_TIMESTAMP
");

$stmt->bind_param("isii", $user_id, $lesson_key, $points, $completed);

if ($stmt->execute()) {
    echo json_encode(["success" => true]);
} else {
    echo json_encode(["error" => $stmt->error]);
}
?>
