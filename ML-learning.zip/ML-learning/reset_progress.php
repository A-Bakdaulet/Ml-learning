<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'error' => 'Пользователь не авторизован']);
    exit;
}

$user_id = $_SESSION['user_id'];

$sql = "DELETE FROM user_progress WHERE user_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);

if ($stmt->execute()) {
    echo json_encode(['success' => true, 'message' => 'Прогресс сброшен']);
} else {
    echo json_encode(['success' => false, 'error' => 'Ошибка сброса: ' . $conn->error]);
}
?>