<?php
session_start();
include 'db.php';

// Проверка администратора (замените на вашу систему)
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Получаем всех пользователей
$sql = "SELECT id, first_name, last_name, email, overall_points, completed_lessons, last_activity 
        FROM users 
        ORDER BY overall_points DESC";
$result = $conn->query($sql);
$users = $result->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 10px; border: 1px solid #ddd; text-align: left; }
        th { background: #f5f5f5; }
        .reset-btn { background: #e74c3c; color: white; border: none; padding: 5px 10px; cursor: pointer; }
    </style>
</head>
<body>
    <h1>Админ панель - Пользователи</h1>
    <table>
        <tr>
            <th>ID</th>
            <th>Имя</th>
            <th>Фамилия</th>
            <th>Email</th>
            <th>Общие очки</th>
            <th>Завершенные уроки</th>
            <th>Последняя активность</th>
            <th>Действия</th>
        </tr>
        <?php foreach ($users as $user): ?>
        <tr>
            <td><?= $user['id'] ?></td>
            <td><?= htmlspecialchars($user['first_name']) ?></td>
            <td><?= htmlspecialchars($user['last_name']) ?></td>
            <td><?= htmlspecialchars($user['email']) ?></td>
            <td><?= $user['overall_points'] ?></td>
            <td><?= $user['completed_lessons'] ?></td>
            <td><?= $user['last_activity'] ?></td>
            <td>
                <button class="reset-btn" onclick="resetProgress(<?= $user['id'] ?>)">
                    Сбросить прогресс
                </button>
            </td>
        </tr>
        <?php endforeach; ?>
    </table>

    <script>
    async function resetProgress(userId) {
        if (!confirm('Сбросить прогресс пользователя?')) return;
        
        try {
            const response = await fetch('reset_user_progress.php', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({user_id: userId})
            });
            const data = await response.json();
            
            if (data.success) {
                alert('Прогресс сброшен!');
                location.reload();
            } else {
                alert('Ошибка: ' + data.error);
            }
        } catch (error) {
            alert('Ошибка сервера');
        }
    }
    </script>
</body>
</html>