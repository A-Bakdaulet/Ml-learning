<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once 'db.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require 'vendor/autoload.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = trim($_POST['email']);

    $stmt = $conn->prepare("SELECT id FROM users WHERE email=?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows == 0) {
        $_SESSION['message'] = "⚠️ Мұндай электрондық пошта тіркелмеген.";
        $_SESSION['message_type'] = "error";
    } else {
        $stmt->close();

        $token = bin2hex(random_bytes(50));
        $expiry = date("Y-m-d H:i:s", strtotime("+1 hour"));

        $stmt = $conn->prepare("UPDATE users SET reset_token=?, reset_expires=? WHERE email=?");
        $stmt->bind_param("sss", $token, $expiry, $email);
        $stmt->execute();
        $stmt->close();

        $reset_link = "http://localhost/ML-learning/reset_password.php?token=" . $token;

        $mail = new PHPMailer(true);
        $mail->CharSet = 'UTF-8';

        try {
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'bakdauletasylhan41@gmail.com';
            $mail->Password = 'ozci omrf efgh odjf';
            $mail->SMTPSecure = 'tls';
            $mail->Port = 587;

            $mail->setFrom('bakdauletasylhan41@gmail.com', 'BrainCode');
            $mail->addAddress($email);

            $mail->isHTML(true);
            $mail->Subject = 'Құпия сөзді қалпына келтіру';
            $mail->Body    = "Құпия сөзді қалпына келтіру үшін мына сілтемеге өтіңіз: <a href='$reset_link'>$reset_link</a>";

            $mail->send();
            $_SESSION['message'] = "✅ Құпия сөзді қалпына келтіру сілтемесі электрондық поштаңызға жіберілді!";
            $_SESSION['message_type'] = "success";

        } catch (Exception $e) {
            $_SESSION['message'] = "❌ Хат жіберу кезінде қате пайда болды: {$mail->ErrorInfo}";
            $_SESSION['message_type'] = "error";
        }
    }

    header("Location: forgot_password.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="kk">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Құпия сөзді қалпына келтіру - BrainCode</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;800&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&family=Montserrat:wght@600&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;800&family=Montserrat:wght@600;700&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link rel="website icon" type="png" href="img/AI-logo.png">
    <style>
        body {
            margin: 0;
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #313364 0%, #275f85 100%);
            color: white;
            position: relative;
            min-height: 100vh;
            overflow-x: hidden;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }

        .container {
            background-color: rgba(70, 72, 102, 0.8);
            padding: 50px;
            border-radius: 25px;
            border: 2px solid #AAABB8;
            box-shadow: 0 15px 50px rgba(0, 0, 0, 0.3);
            max-width: 450px;
            width: 100%;
            text-align: center;
        }
        .form-group {
            margin-bottom: 20px;
            text-align: left;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #AAABB8;
            font-weight: 600;
            font-size: 16px;
        }

        .form-group input {
            width: 94%;
            padding: 14px;
            border: 2px solid #AAABB8;
            border-radius: 12px;
            background-color: rgba(37, 39, 77, 0.7);
            color: white;
            font-size: 16px;
            font-family: 'Inter', sans-serif;
            transition: all 0.3s ease;
        }

        .form-group input:focus {
            outline: none;
            border-color: #2E9CCA;
            box-shadow: 0 0 10px rgba(46, 156, 202, 0.3);
        }

        .form-group input::placeholder {
            color: #6b7280;
        }

        .btn-primary {
            width: 100%;
            padding: 14px;
            background: linear-gradient(45deg, #2E9CCA, #29648A);
            color: white;
            border: none;
            border-radius: 12px;
            font-size: 18px;
            font-weight: 600;
            font-family: 'Montserrat', sans-serif;
            cursor: pointer;
            transition: all 0.3s ease;
            margin-top: 10px;
        }

        .btn-primary:hover{
            transform: scale(1.01);
            box-shadow: 0 8px 25px rgba(46, 156, 202, 0.5);
        }

        .message {
            margin-top: 15px;
            font-weight: 600;
        }

        .success {
            color: #4ade80;
        }

        .error {
            color: #ff6b6b;
        }
    </style>
</head>
<body>

<div class="container">
<h1>Құпия сөзді қалпына келтіру</h1>
<?php
    if (isset($_SESSION['message'])) {
        echo '<div class="message ' . $_SESSION['message_type'] . '">' . $_SESSION['message'] . '</div>';
        unset($_SESSION['message']);
        unset($_SESSION['message_type']);
    }
    ?>
<form method="POST" action="">
    <div class="form-group">
        <label for="email">Электрондық пошта</label>
        <input type="email" id="email" name="email" placeholder="Электрондық поштаңызды енгізіңіз" required>
    </div>
    <button type="submit" class="btn-primary">Сілтемені жіберу</button>
</form>
</div>

</body>
</html>
