<?php
session_start();
include 'db.php';

// Очищаем буфер вывода
while (ob_get_level()) ob_end_clean();

header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['points' => 0, 'completedLessons' => []]);
    exit;
}

$user_id = $_SESSION['user_id'];

try {
    $sql = "SELECT lesson_key, points FROM user_progress WHERE user_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();

    $totalPoints = 0;
    $completedLessons = [];

    while ($row = $result->fetch_assoc()) {
        $completedLessons[] = $row['lesson_key'];
        $totalPoints += $row['points'];
    }

    echo json_encode([
        'points' => $totalPoints,
        'completedLessons' => $completedLessons
    ]);

} catch (Exception $e) {
    echo json_encode(['points' => 0, 'completedLessons' => [], 'error' => $e->getMessage()]);
}
?>