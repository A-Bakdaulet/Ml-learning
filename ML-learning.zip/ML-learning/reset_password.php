<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once 'db.php';
session_start();

if (!isset($_GET['token'])) {
    die("⚠️ Токен берілмеді.");
}

$token = $_GET['token'];

// Токенді тексеру
$stmt = $conn->prepare("SELECT id, reset_expires FROM users WHERE reset_token=?");
$stmt->bind_param("s", $token);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    die("⚠️ Сілтеме жарамсыз немесе мерзімі өткен.");
}

$user = $result->fetch_assoc();

// Токеннің мерзімін тексеру
if (strtotime($user['reset_expires']) < time()) {
    die("⚠️ Сілтеменің мерзімі өтті.");
}

$message = '';
$message_type = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $new_password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    if ($new_password !== $confirm_password) {
        $message = "Құпиясөздер сәйкес келмейді!";
        $message_type = "error";
    } elseif (strlen($new_password) < 8) {
        $message = "Құпиясөз кемінде 8 таңбадан тұруы керек!";
        $message_type = "error";
    } else {
        $password_hash = password_hash($new_password, PASSWORD_DEFAULT);
        $stmt = $conn->prepare("UPDATE users SET password=?, reset_token=NULL, reset_expires=NULL WHERE id=?");
        $stmt->bind_param("si", $password_hash, $user['id']);
        $stmt->execute();
        $message = "✅ Құпиясөз сәтті өзгертілді!<br>
                    <a href='login.html' class='btn btn-primary center-btn'>Кіру</a>";
        $message_type = "success";
    }
}
?>

<!DOCTYPE html>
<html lang="kk">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Құпиясөзді қалпына келтіру - BrainCode</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;800&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@600;700&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link rel="website icon" type="png" href="img/AI-logo.png">
    <style>
        body {
            margin: 0;
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #313364 0%, #275f85 100%);
            color: white;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            padding: 20px;
        }
        .container {
            background-color: rgba(70, 72, 102, 0.8);
            padding: 50px;
            border-radius: 25px;
            border: 2px solid #AAABB8;
            box-shadow: 0 15px 50px rgba(0, 0, 0, 0.3);
            max-width: 450px;
            width: 100%;
            text-align: center;
        }
        .form-group {
            margin-bottom: 20px;
            text-align: left;
        }
        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #AAABB8;
            font-weight: 600;
            font-size: 16px;
        }
        .form-group input {
            width: 94%;
            padding: 14px;
            border: 2px solid #AAABB8;
            border-radius: 12px;
            background-color: rgba(37, 39, 77, 0.7);
            color: white;
            font-size: 16px;
            transition: all 0.3s ease;
        }
        .form-group input:focus {
            outline: none;
            border-color: #2E9CCA;
            box-shadow: 0 0 10px rgba(46, 156, 202, 0.3);
        }
        .btn-primary {
            display: inline-block;
            padding: 14px 30px;
            background: linear-gradient(45deg, #2E9CCA, #29648A);
            color: white;
            border: none;
            border-radius: 12px;
            font-size: 18px;
            font-weight: 600;
            font-family: 'Montserrat', sans-serif;
            cursor: pointer;
            transition: all 0.3s ease;
            margin-top: 20px;
            text-align: center;
            text-decoration: none;
        }
        .btn-primary:hover {
            transform: scale(1.01);
            box-shadow: 0 8px 25px rgba(46, 156, 202, 0.5);
        }
        .center-btn {
            display: block;
            margin: 20px auto 0 auto; /* по центру */
        }
        .message {
            margin-top: 15px;
            font-weight: 600;
        }
        .success { color: #4ade80; }
        .error { color: #ff6b6b; }
    </style>
</head>
<body>
    <div class="container">
        <?php if ($message): ?>
        <div class="message <?php echo $message_type; ?>">
            <?php echo $message; ?>
        </div>
        <?php endif; ?>

        <?php if ($message_type !== 'success'): ?>
        <form method="POST" action="">
            <div class="form-group">
                <label for="password">Жаңа құпиясөз</label>
                <input type="password" id="password" name="password" placeholder="Жаңа құпиясөзді енгізіңіз" required>
            </div>
            <div class="form-group">
                <label for="confirm_password">Құпиясөзді қайталау</label>
                <input type="password" id="confirm_password" name="confirm_password" placeholder="Құпиясөзді қайталаңыз" required>
            </div>
            <button type="submit" class="btn-primary">Құпиясөзді қалпына келтіру</button>
        </form>
        <?php endif; ?>
    </div>
</body>
</html>
